# Waybar Theme Starter

Create your own Waybar Theme based on this starter theme.

- Copy the folder "~/.config/waybar/themes/starter" and define a custom folder name
- Open config.sh and enter the name of your new theme
- Select the theme with the Waybar Themeswitcher with <kbd>SUPER</kbd>+<kbd>CTRL</kbd>+<kbd>T</kbd>
- Start your customization

You can enable, disable and reorder waybar modules in the config file.

Your custom theme will not be overwritten with an update of the dotfiles.
